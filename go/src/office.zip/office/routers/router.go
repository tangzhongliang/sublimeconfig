package routers

import (
	"github.com/astaxie/beego"
	"office/controllers"
)

func Init() {
	beego.Router("/", &controllers.MainController{})
	beego.Router("/notify", &controllers.MainController{}, "POST:Notify")
	beego.Router("/auth", &controllers.MainController{}, "GET:Auth")
}
