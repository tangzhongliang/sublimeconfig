package controllers

import (
	"encoding/json"
	"fmt"
	"github.com/astaxie/beego"
	"io/ioutil"
	"net/http"
	"net/url"
	"strings"
)

// qZe9KdkYmG7sLxercXKdfQV
//https://login.microsoftonline.com/common/adminconsent?client_id=5e43d117-f0cd-481e-a047-1498850f77ca&redirect_uri=http%3A%2F%2Frocket.hezhensh.com%2Fauth&state=12345
//https://login.microsoftonline.com/common/adminconsent?client_id=5e43d117-f0cd-481e-a047-1498850f77ca&redirect_uri=https://rocket.hezhensh.com:4443/auth&state=12345
type MainController struct {
	beego.Controller
}

func (c *MainController) Get() {
	c.Data["Website"] = "beego.me"
	c.Data["Email"] = "astaxie@gmail.com"
	c.TplName = "index.tpl"
}
func (this *MainController) Notify() {
	result := this.Ctx.Request.FormValue("payload")
	fmt.Println(result)
	this.Ctx.ResponseWriter.WriteHeader(http.StatusOK)
}

type OfficeApp struct {
	TokenType    string `json:"token_type"`
	Scope        string `json:"scope"`
	ExpiresIn    int    `json:"expires_in"`
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
}

func (this *MainController) Auth() {
	hasuser(this)
}

func nouser(this *MainController) {
	fmt.Println("auth")
	result := this.GetString("code", "")
	fmt.Println(result)
	form := url.Values{}
	form.Add("client_id", "5e43d117-f0cd-481e-a047-1498850f77ca")
	form.Add("scope", "user.read mail.read")
	form.Add("scope", "https://graph.microsoft.com/.default")
	form.Add("code", result)
	form.Add("redirect_uri", "https://rocket.hezhensh.com:4443/auth&state=12345")
	form.Add("client_secret", "qZe9KdkYmG7sLxercXKdfQV")
	form.Add("grant_type", "authorization_code")
	form.Add("grant_type", "client_credentials")
	req, err := http.NewRequest("POST", "https://login.microsoftonline.com/common/oauth2/v2.0/token", strings.NewReader(form.Encode()))
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	if err != nil {
		panic(err)
	} else {
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			panic(err)
		} else {
			bts, _ := ioutil.ReadAll(res.Body)
			fmt.Println(string(bts))
			app := OfficeApp{}
			json.Unmarshal(bts, &app)
		}
	}
	this.Ctx.ResponseWriter.WriteHeader(http.StatusOK)
}
func hasuser(this *MainController) {
	fmt.Println("auth")
	result := this.GetString("tenant", "")
	fmt.Println(result)
	form := url.Values{}
	form.Add("client_id", "5e43d117-f0cd-481e-a047-1498850f77ca")
	// form.Add("scope", "user.read mail.read")
	form.Add("scope", "https://graph.microsoft.com/.default")
	// form.Add("code", result)
	// form.Add("redirect_uri", "https%3A%2F%2Frocket.hezhensh.com%3A4443")
	form.Add("client_secret", "qZe9KdkYmG7sLxercXKdfQV")
	// form.Add("grant_type", "authorization_code")
	form.Add("grant_type", "client_credentials")
	req, err := http.NewRequest("POST", "https://login.microsoftonline.com/"+result+"/oauth2/v2.0/token", strings.NewReader(form.Encode()))
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	if err != nil {
		panic(err)
	} else {

		res, err := http.DefaultClient.Do(req)
		if err != nil {
			panic(err)
		} else {
			bts, _ := ioutil.ReadAll(res.Body)
			fmt.Println(string(bts))
			app := OfficeApp{}
			json.Unmarshal(bts, &app)
		}
	}
	this.Ctx.ResponseWriter.WriteHeader(http.StatusOK)
}
