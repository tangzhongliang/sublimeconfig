package main

import (
	"fmt"
	"github.com/astaxie/beego"
	"office/routers"
)

func main() {
	fmt.Println("start")
	routers.Init()
	beego.Run()
}
